/* HTML */

/* 1. Create a basic structure of your programme. 
Remember to write stuff which you would like to display when page is loaded for the first time.
For a button, put a name of function in HTML and its trigger - "on click". */


/* CSS */

/* 2. Add styling to your page
Remember to set background-color of squares, pick the color you would like 
to display when page is loaded.
 */


/* JavaScript */

/* 3.
- Wrap everything into the function you called in HTML
- Check what is written on a button and if its needed, change it.
- Generate 3 random color codes by using Math.random and Math.floor.
- Pick one color randomly and wite its color code on the top of the page.
- Add function by which you will check if clicked square has the color which
 is displayed on top of the page.
 */