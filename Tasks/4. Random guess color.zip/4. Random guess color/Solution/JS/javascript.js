function changeColors() {

    const button = document.getElementById("button");

    if(button.innerText === "START"){
        button.innerText = "NEW COLOURS";
    }else{
        button.innerText= "NEW COLOURS";
    }

    document.getElementById("paragraph").style.display = "inline";
    
    var r1 = Math.floor(Math.random() * 256);
    var g1 = Math.floor(Math.random() * 256);
    var b1 = Math.floor(Math.random() * 256);
    color1 = "rgb(" + r1 + ", " + g1 + ", " + b1 + ")";
    

    var r2 = Math.floor(Math.random() * 256);
    var g2 = Math.floor(Math.random() * 256);
    var b2 = Math.floor(Math.random() * 256);
    color2 = "rgb(" + r2 + ", " + g2 + ", " + b2 + ")";
    

    var r3 = Math.floor(Math.random() * 256);
    var g3 = Math.floor(Math.random() * 256);
    var b3 = Math.floor(Math.random() * 256);
    color3 = "rgb(" + r3 + ", " + g3 + ", " + b3 + ")";
    

    document.getElementById("square1").style.backgroundColor = color1;
    document.getElementById("square2").style.backgroundColor = color2;
    document.getElementById("square3").style.backgroundColor = color3;
    
    mix=[color1, color2, color3];
    
    mix.sort(() => Math.random() - 0.5);
    
    document.getElementById("h1").innerHTML = mix[0];
    
    const square1 = document.getElementById("square1");
    const square2 = document.getElementById("square2");
    const square3 = document.getElementById("square3");

    square1.addEventListener("click", function(){ 
        if (mix[0] == color1){
            document.getElementById("h1").style.backgroundColor = color1;
        }
    });

    square2.addEventListener("click", function(){ 
        if (mix[0] == color2){
            document.getElementById("h1").style.backgroundColor = color2;
        }
    });

    square3.addEventListener("click", function(){ 
        if (mix[0] == color3){
            document.getElementById("h1").style.backgroundColor = color3;
        }
    });

    document.getElementById("h1").style.backgroundColor = "rgb(213, 213, 213)"
}


