// Marco Calderaro
//Part 2 - Change images

// (CLICK)
// Take the id´s from the html so you can make it interactive
// Create function "changepurple" so you can change the purple picture
// Create the function "changeorange" so you can change the orange picture
// When you "click" on the picture it tells the function to start  

// (SET CLICKS)
// Take the id´s from the html so you can make it interactive
// Let the clicks start at 0
// Create the function "amount" 
// ++ makes the value increase
// So if you click the picture 5 times it changes
// When you "click" on the picture it tells the function to start

// (KEYDOWN)
// Take the id´s from the html so you can make it interactive
// Create the function "keyboard", that tells which letters to press
// key identifies the keyboard bottons and make it equal to the displayed letters.
// if you press "k" on the keyboard the orange picture will show 
// if you press "d" on the keyboard the purple picture will show 
// By pressing down a key on the keyboard, 
// it tells the function to start. The function tells witch keys. 

// (BUTTON)
// Take the id´s from the html so you can make it interactive
// Create the function "shift", which takes the class "hidden" with the display: "none"
// and toggles between the pictures. 
// By clicking the button, the function starts

// (TIMEOUT)
// Take the id´s from the html so you can make it interactive
// Set the timeout and calls the function inside,
// to change the elements in 10 sec in miliseconds

// (INTERVAL)
// Take the id´s from the html so you can make it interactive
// Set the style for the picture from the start
// Set the interval to shift the pictures every second in milisecond
// If the first picture is == "block", as we made it to be above, after 1 sec it will 
// be displayed as "none" and the second picture will be "block".
// When the second picture is == "block", it will switch back and continue this way every second 




