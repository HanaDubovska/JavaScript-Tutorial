// Marco Calderaro
//Part 2 - Change images

// (CLICK)
// Takes the id´s from the html so you can make it interactive
let clickpurple = document.getElementById("clickpurple");
let clickorange = document.getElementById("clickorange");

// Creates function "changepurple" so you can change the purple picture
function changepurple() {
    clickpurple.style.display = "none";
    clickorange.style.display = "block";
}

// Creates the function "changeorange" so you can change the orange picture
function changeorange(){
    clickpurple.style.display = "block";
    clickorange.style.display = "none";
}

// When you "click" on the picture it tells the function to start  
clickpurple.addEventListener("click", changepurple);
clickorange.addEventListener("click", changeorange);

// (SET CLICKS)
// Takes the id´s from the html so you can make it interactive
let purpleclicks = document.getElementById("setpurple");
let orangeclicks = document.getElementById("setorange");

// Lets the clicks start at 0
let clicks = 0;

// Creates the function "amount" 
// ++ makes the value increase
// So if you click the picture 5 times it changes
function amount(){
    clicks++
    if (clicks==5) {    
        purpleclicks.style.display = "none";
        orangeclicks.style.display = "block";  

    }

}

// When you "click" on the picture it tells the function to start
purpleclicks.addEventListener("click", amount);

// (KEYDOWN)
// Takes the id´s from the html so you can make it interactive
let purplekey = document.getElementById("keypurple");
let orangekey = document.getElementById("keyorange");

// Creates the function "keyboard", that tells which letters to press
// key identifies the keyboard bottons and make it equal to the displayed letters.
// if you press "k" on the keyboard the orange picture will show 
// if you press "d" on the keyboard the purple picture will show 
function keyboard(e){
    if (e.key == "k") {
        purplekey.style.display = "none";
        orangekey.style.display = "block";
        
    }
    if (e.key == "d") {
        purplekey.style.display = "block";
        orangekey.style.display = "none";
        
    }
}

// By pressing down a key on the keyboard, 
// it tells the function to start. The function tells witch keys. 
document.addEventListener("keydown", keyboard);

// (BUTTON)
// Takes the id´s from the html so you can make it interactive
let purplebtn = document.getElementById("btnpurple");
let orangebtn = document.getElementById("btnorange");
let btn = document.getElementById("btn");

// Creates the function "shift", which takes the class "hidden" with the display: "none"
// and toggles between the pictures. 
function shift() {
    purplebtn.classList.toggle("hidden");
    orangebtn.classList.toggle("hidden");
}

// By clicking the button, the function starts
btn.addEventListener("click", shift);

// (TIMEOUT)
// Takes the id´s from the html so you can make it interactive
let purpletime = document.getElementById("timepurple");
let orangetime = document.getElementById("timeorange");

// Sets the timeout and calls the function inside,
// to change the elements in 10 sec in miliseconds
setTimeout(() => {
    orangetime.style.display = "block";
    purpletime.style.display = "none";
}, 10000); 


// (INTERVAL)
// Takes the id´s from the html so you can make it interactive
let purpleint = document.getElementById("intpurple");
let orangeint = document.getElementById("intorange");

//Sets the style for the picture from the start
purpleint.style.display = "block"; 

// Sets the interval to shift the pictures every second in milisecond
// If the first picture is == "block", as we made it to be above, after 1 sec it will 
// be displayed as "none" and the second picture will be "block".
// When the second picture is == "block", it will switch back and continue this way every second 
setInterval(() => {
   
    if (purpleint.style.display == "block") {
      purpleint.style.display = "none";
      orangeint.style.display = "block";  
    }
    else if (orangeint.style.display == "block") {
    orangeint.style.display = "none";
    purpleint.style.display = "block";
    }  
}, 1000);





