/* HTML */

/* 1. Create a span element in a div, dont forget to assign id to your element 
(you will need this for styling your element in CSS and also for accesing it with Java Script. */


/* CSS */

/* 2. Add styling to your dot
- Position your dot, for ex. by using position absolute.
- Scale your dot, and add circle shape to it by adding border-radius parameter.
- Set background-color, pick the color you would like to display when page is loaded.
 */


/* JavaScript */

/* 3.
- Access the dot by id. 
- Save it into variable.
- Add EventListener to your dot with an event - mouseover and mouseout.
- Define functions, their purpose should be to change color of the dots based on the event you added in last step.
 */
