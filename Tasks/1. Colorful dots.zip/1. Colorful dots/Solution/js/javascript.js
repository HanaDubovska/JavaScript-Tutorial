/* Dot 1  */

let dot1 = document.getElementById("dot1");

dot1.addEventListener("mouseover", mouseOver_dot1);
dot1.addEventListener("mouseout", mouseOut_dot1);

function mouseOver_dot1() {
    dot1.style.backgroundColor = "green";
}

function mouseOut_dot1 (){
    dot1.style.backgroundColor = "black";
}

/* Dot 2  */

let dot2 = document.getElementById("dot2");

dot2.addEventListener("mouseover", mouseOver_dot2);
dot2.addEventListener("mouseout", mouseOut_dot2);

function mouseOver_dot2() {
    dot2.style.backgroundColor = "yellow";
}

function mouseOut_dot2 (){
    dot2.style.backgroundColor = "black";
}

/* Dot 3  */

let dot3 = document.getElementById("dot3");

dot3.addEventListener("mouseover", mouseOver_dot3);
dot3.addEventListener("mouseout", mouseOut_dot3);

function mouseOver_dot3() {
    dot3.style.backgroundColor = "red";
}

function mouseOut_dot3(){
    dot3.style.backgroundColor = "black";
}

/* Dot 4  */

let dot4 = document.getElementById("dot4");

dot4.addEventListener("mouseover", mouseOver_dot4);
dot4.addEventListener("mouseout", mouseOut_dot4);

function mouseOver_dot4() {
    dot4.style.backgroundColor = "brown";
}

function mouseOut_dot4 (){
    dot4.style.backgroundColor = "black";
}

/* Dot 5  */

let dot5 = document.getElementById("dot5");

dot5.addEventListener("mouseover", mouseOver_dot5);
dot5.addEventListener("mouseout", mouseOut_dot5);

function mouseOver_dot5() {
    dot5.style.backgroundColor = "yellow";
}

function mouseOut_dot5 (){
    dot5.style.backgroundColor = "black";
}

/* Dot 6  */

let dot6 = document.getElementById("dot6");

dot6.addEventListener("mouseover", mouseOver_dot6);
dot6.addEventListener("mouseout", mouseOut_dot6);

function mouseOver_dot6() {
    dot6.style.backgroundColor = "purple";
}

function mouseOut_dot6(){
    dot6.style.backgroundColor = "black";
}

/* Dot 7  */

let dot7 = document.getElementById("dot7");

dot7.addEventListener("mouseover", mouseOver_dot7);
dot7.addEventListener("mouseout", mouseOut_dot7);

function mouseOver_dot7() {
    dot7.style.backgroundColor = "rebeccapurple";
}

function mouseOut_dot7 (){
    dot7.style.backgroundColor = "black";
}

/* Dot 8  */

let dot8 = document.getElementById("dot8");

dot8.addEventListener("mouseover", mouseOver_dot8);
dot8.addEventListener("mouseout", mouseOut_dot8);

function mouseOver_dot8() {
    dot8.style.backgroundColor = "rosybrown";
}

function mouseOut_dot8 (){
    dot8.style.backgroundColor = "black";
}

/* Dot 9  */

let dot9 = document.getElementById("dot9");

dot9.addEventListener("mouseover", mouseOver_dot9);
dot9.addEventListener("mouseout", mouseOut_dot9);

function mouseOver_dot9() {
    dot9.style.backgroundColor = "goldenrod";
}

function mouseOut_dot9(){
    dot9.style.backgroundColor = "black";
}

/* Dot 10  */

let dot10 = document.getElementById("dot10");

dot10.addEventListener("mouseover", mouseOver_dot10);
dot10.addEventListener("mouseout", mouseOut_dot10);

function mouseOver_dot10() {
    dot10.style.backgroundColor = "yellowgreen";
}

function mouseOut_dot10 (){
    dot10.style.backgroundColor = "black";
}

/* Dot 11  */

let dot11 = document.getElementById("dot11");

dot11.addEventListener("mouseover", mouseOver_dot11);
dot11.addEventListener("mouseout", mouseOut_dot11);

function mouseOver_dot11() {
    dot11.style.backgroundColor = "coral";
}

function mouseOut_dot11 (){
    dot11.style.backgroundColor = "black";
}

/* Dot 12  */

let dot12 = document.getElementById("dot12");

dot12.addEventListener("mouseover", mouseOver_dot12);
dot12.addEventListener("mouseout", mouseOut_dot12);

function mouseOver_dot12() {
    dot12.style.backgroundColor = "yellowgreen";
}

function mouseOut_dot12 (){
    dot12.style.backgroundColor = "black";
}

/* Dot 13  */

let dot13 = document.getElementById("dot13");

dot13.addEventListener("mouseover", mouseOver_dot13);
dot13.addEventListener("mouseout", mouseOut_dot13);

function mouseOver_dot13() {
    dot13.style.backgroundColor = "fuchsia";
}

function mouseOut_dot13(){
    dot13.style.backgroundColor = "black";
}

/* Dot 14  */

let dot14 = document.getElementById("dot14");

dot14.addEventListener("mouseover", mouseOver_dot14);
dot14.addEventListener("mouseout", mouseOut_dot14);

function mouseOver_dot14() {
    dot14.style.backgroundColor = "green";
}

function mouseOut_dot14 (){
    dot14.style.backgroundColor = "black";
}

/* Dot 15  */

let dot15 = document.getElementById("dot15");

dot15.addEventListener("mouseover", mouseOver_dot15);
dot15.addEventListener("mouseout", mouseOut_dot15);

function mouseOver_dot15() {
    dot15.style.backgroundColor = "peru";
}

function mouseOut_dot15 (){
    dot15.style.backgroundColor = "black";
}

/* Dot 16  */

let dot16 = document.getElementById("dot16");

dot16.addEventListener("mouseover", mouseOver_dot16);
dot16.addEventListener("mouseout", mouseOut_dot16);

function mouseOver_dot16() {
    dot16.style.backgroundColor = "khaki";
}

function mouseOut_dot16(){
    dot16.style.backgroundColor = "black";
}

/* Dot 17  */

let dot17 = document.getElementById("dot17");

dot17.addEventListener("mouseover", mouseOver_dot17);
dot17.addEventListener("mouseout", mouseOut_dot17);

function mouseOver_dot17() {
    dot17.style.backgroundColor = "khaki";
}

function mouseOut_dot17 (){
    dot17.style.backgroundColor = "black";
}

/* Dot 18  */

let dot18 = document.getElementById("dot18");

dot18.addEventListener("mouseover", mouseOver_dot18);
dot18.addEventListener("mouseout", mouseOut_dot18);

function mouseOver_dot18() {
    dot18.style.backgroundColor = "blue";
}

function mouseOut_dot18 (){
    dot18.style.backgroundColor = "black";
}

