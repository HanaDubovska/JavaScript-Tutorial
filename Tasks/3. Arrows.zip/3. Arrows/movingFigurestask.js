// Make two circles and move on of them using the arrow keys.

// Create circles

// Show the circles on page


// Style the moving circle

// Style the start position of the moving circle.

// Style the  of the static circle

// Style the position of the static circle.


// Set a variable that indicates the number of pixels the circle will move, when told to.

// Create switch that sets up rules for the four arrow keys.

// Try changing the moveBy and see what happens...

// You can also try to add another circle that reacts on four different keys.
