// Make two circles and move on of them using the arrow keys.

// Create circles
let movingCircle = document.createElement("div");
let staticCircle = document.createElement("div");
// Show the circles on page
document.getElementById("stage4").append(staticCircle);
document.getElementById("stage4").append(movingCircle);

// Style the moving circle
movingCircle.style.width = "100px";
movingCircle.style.height = "100px";
movingCircle.style.borderRadius = "50%";
movingCircle.style.backgroundColor = "green";
// Style the start position of the moving circle.
movingCircle.style.position = "relative";
movingCircle.style.left = 300 + "px";
movingCircle.style.top = 0 + "px";
// Style the  of the static circle
staticCircle.style.width = "100px";
staticCircle.style.height = "100px";
staticCircle.style.borderRadius = "50%";
staticCircle.style.backgroundColor = "blue";
// Style the position of the static circle.
staticCircle.style.position = "relative";
staticCircle.style.left = 900 + "px";
staticCircle.style.top = 300 + "px";

// Set a variable that indicates the number of pixels the circle will move, when told to.
let moveBy = 100;

// Create switch that sets up rules for the four arrow keys.
let stage4 = document.getElementById("stage4");

if (stage4.classList.contains("show")) {
  window.addEventListener("keydown", (e) => {
    switch (e.key) {
      case "ArrowLeft":
        movingCircle.style.left =
          parseInt(movingCircle.style.left) - moveBy + "px";
        break;
      case "ArrowRight":
        movingCircle.style.left =
          parseInt(movingCircle.style.left) + moveBy + "px";
        break;
      case "ArrowUp":
        movingCircle.style.top =
          parseInt(movingCircle.style.top) - moveBy + "px";
        break;
      case "ArrowDown":
        movingCircle.style.top =
          parseInt(movingCircle.style.top) + moveBy + "px";
        break;
    }
  });
}
// Try changing the moveBy and see what happens...

// You can also try to add another circle that reacts on four different keys.
