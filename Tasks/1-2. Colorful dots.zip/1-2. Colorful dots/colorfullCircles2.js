// PETER BUDOLFSEN

// Create circle that needs to be clicked.
// Create circle in console
let circle1 = document.createElement("div");
// Show it on the HTML page
document.getElementById("stage2").append(circle1);

// Style circle
circle1.style.width = 100 + "px";
circle1.style.height = 100 + "px";
circle1.style.borderRadius = 50 + "%";
circle1.style.border = "solid";
circle1.style.position = "absolute";
circle1.style.left = 70 + "vw";
circle1.style.top = 60 + "vh";

// Create mouseover event, that changes the background color
circle1.addEventListener("mouseover", function () {
  circle1.style.backgroundColor = "red";
});
// Create mouseover event, that changes the background color to transparent, when mouse leaves.
circle1.addEventListener("mouseout", function () {
  circle1.style.backgroundColor = "transparent";
});

// NOTE!!! You can also add eventlistener in another and older way that will be supported in Internet Explorer 8 and earlier versions:
// https://www.w3schools.com/jsref/event_onmouseover.asp
// circle1.onmouseover = function () {
//   circle1.style.backgroundColor = "red";
// };

// Create a second circle
let circle2 = document.createElement("div");
// Show it on the HTML page
document.getElementById("stage2").append(circle2);
// Style circle
circle2.style.width = 200 + "px";
circle2.style.height = 200 + "px";
circle2.style.borderRadius = 50 + "%";
circle2.style.border = "solid";
circle2.style.position = "absolute";
circle2.style.left = 10 + "vw";
circle2.style.top = 50 + "vh";

// Create mouseover event, that changes the background color
circle2.addEventListener("mouseover", function () {
  circle2.style.backgroundColor = "blue";
});
// Create mouseover event, that changes the background color to transparent, when mouse leaves.
circle2.addEventListener("mouseout", function () {
  circle2.style.backgroundColor = "transparent";
});

// Create a third circle
let circle3 = document.createElement("div");
// Show circle on page
document.getElementById("stage2").append(circle3);
// Style circle
circle3.style.width = 20 + "px";
circle3.style.height = 20 + "px";
circle3.style.borderRadius = 50 + "%";
circle3.style.border = "solid";
circle3.style.position = "absolute";
circle3.style.left = 40 + "vw";
circle3.style.top = 40 + "vh";

// Create mouseover event, that changes the background color
circle3.addEventListener("mouseover", function () {
  circle3.style.backgroundColor = "purple";
});
// Create mouseover event, that changes the background color to transparent, when mouse leaves.
circle3.addEventListener("mouseout", function () {
  circle3.style.backgroundColor = "transparent";
});

// Create a fourth circle
let circle4 = document.createElement("div");
// Show circle on page
document.getElementById("stage2").append(circle4);
// Style circle
circle4.style.width = 50 + "px";
circle4.style.height = 50 + "px";
circle4.style.borderRadius = 50 + "%";
circle4.style.border = "solid";
circle4.style.position = "absolute";
circle4.style.left = 20 + "vw";
circle4.style.top = 20 + "vh";

// Create mouseover event, that changes the background color
circle4.addEventListener("mouseover", function () {
  circle4.style.backgroundColor = "orange";
});
// Create mouseover event, that changes the background color to transparent, when mouse leaves.
circle4.addEventListener("mouseout", function () {
  circle4.style.backgroundColor = "transparent";
});

// Create a fifth circle
let circle5 = document.createElement("div");
// Show circle on page
document.getElementById("stage2").append(circle5);
// Style circle
circle5.style.width = 70 + "px";
circle5.style.height = 70 + "px";
circle5.style.borderRadius = 50 + "%";
circle5.style.border = "solid";
circle5.style.position = "absolute";
circle5.style.left = 60 + "vw";
circle5.style.top = 30 + "vh";

// Create mouseover event, that changes the background color
circle5.addEventListener("mouseover", function () {
  circle5.style.backgroundColor = "yellow";
});
// Create mouseover event, that changes the background color to transparent, when mouse leaves.
circle5.addEventListener("mouseout", function () {
  circle5.style.backgroundColor = "transparent";
});

// Create a sixth circle
let circle6 = document.createElement("div");
// Show circle on page
document.getElementById("stage2").append(circle6);
// Style circle
circle6.style.width = 150 + "px";
circle6.style.height = 150 + "px";
circle6.style.borderRadius = 50 + "%";
circle6.style.border = "solid";
circle6.style.position = "absolute";
circle6.style.left = 80 + "vw";
circle6.style.top = 40 + "vh";

// Create mouseover event, that changes the background color
circle6.addEventListener("mouseover", function () {
  circle6.style.backgroundColor = "pink";
});
// Create mouseover event, that changes the background color to transparent, when mouse leaves.
circle6.addEventListener("mouseout", function () {
  circle6.style.backgroundColor = "transparent";
});

// Create mouseclick event on the red circle, that changes the background color permanently and shows the text "congratulations".
circle1.addEventListener("mouseup", function () {
  circle1.style.backgroundColor = "red";

  let congratulations = document.createElement("h4");
  congratulations.innerHTML = "Congratulations";
  congratulations.style.textTransform = "uppercase";
  congratulations.style.marginTop = "70vh";
  congratulations.style.fontSize = "60px";
  congratulations.style.textAlign = "center";
  // Now it should only show the congratulations text on the first click... Therefore make an if-statement that only appends the text ones.
  if (document.getElementsByTagName("h4").length == 0) {
    document.getElementById("stage2").append(congratulations);
  }
  // Make sure the circle stays red, when you leave it after clicking.
  circle1.onmouseout = null;

  // Button

});
