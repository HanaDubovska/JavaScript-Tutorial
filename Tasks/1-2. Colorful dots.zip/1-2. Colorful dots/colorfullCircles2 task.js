// PETER BUDOLFSEN

// Create circle that needs to be clicked.
// Create circle in console

// Show it on the HTML page


// Style circle


// Create mouseover event, that changes the background color

// Create mouseover event, that changes the background color to transparent, when mouse leaves.

// NOTE!!! You can also add eventlistener in another and older way that will be supported in Internet Explorer 8 and earlier versions:
// https://www.w3schools.com/jsref/event_onmouseover.asp
// circle1.onmouseover = function () {
//   circle1.style.backgroundColor = "red";
// };

// Create a second circle

// Show it on the HTML page

// Style circle


// Create mouseover event, that changes the background color

// Create mouseover event, that changes the background color to transparent, when mouse leaves.


// Create a third circle

// Show circle on page

// Style circle


// Create mouseover event, that changes the background color

// Create mouseover event, that changes the background color to transparent, when mouse leaves.

// Create a fourth circle

// Show circle on page

// Style circle


// Create mouseover event, that changes the background color

// Create mouseover event, that changes the background color to transparent, when mouse leaves.


// Create a fifth circle

// Show circle on page

// Style circle


// Create mouseover event, that changes the background color

// Create mouseover event, that changes the background color to transparent, when mouse leaves.


// Create a sixth circle

// Show circle on page

// Style circle


// Create mouseover event, that changes the background color

// Create mouseover event, that changes the background color to transparent, when mouse leaves.


// Create mouseclick event on the red circle, that changes the background color permanently and shows the text "congratulations".

// Now it should only show the congratulations text on the first click... Therefore make an if-statement that only appends the text ones.
