// https://www.youtube.com/watch?v=GUEB9FogoP8

// Create text that needs to be animated and append it to the HTML.
// type "paragraph"
// text: "My first JS animation"
let animationText = document.createElement("p");
animationText.innerHTML = "My first JS animation";
document.getElementById("stage6").append(animationText);

animationText.style.fontSize = "80px";
animationText.style.textAlign = "center";
animationText.style.lineHeight = "100vh";

// Now we need to extract each letter from the p-element and put them into an array.
let strText = animationText.textContent;
let splitText = strText.split("");

// ...and hide the original textelement.
animationText.textContent = "";

// Now we can loop through the array and wrap each letter in a <span>.
// That way we can later add a new class to the letters in different ways.
for (let index = 0; index < splitText.length; index++) {
  animationText.innerHTML += "<span>" + splitText[index] + "</span>";
}
// For later use we will also make an array with the letters in the reverse order.
let reversed = Array.from(document.getElementsByTagName("span")).reverse();

/* Now its time to set the variables and clear-functions that we need for each animation, 
before we can actually make the animation function.*/

let letter = 0;
if (stage6.classList.contains("show")) {
  let timer1 = setInterval(addClass1, 100);
  let timer2 = null;
  let timer3 = null;

  function complete() {
    clearInterval(timer1);
    timer1 = null;
  }

  function complete2() {
    clearInterval(timer2);
    timer2 = null;
  }

  function complete3() {
    clearInterval(timer3);
    timer3 = null;
  }

  // 1st animation...Now create a function that adds a new class to each letter in a certain time interval.
  function addClass1() {
    let span = animationText.querySelectorAll("span")[letter];
    span.classList.add("fade");
    letter++;

    //   Stop the function when class has been added to all letters.
    if (letter === splitText.length) {
      letter = 0;
      complete();
      timer2 = setInterval(addClass2, 100); //start the next animation, when this one is completed.
      // Maybe try and change the number 100 and see what happens to the animation.
      return;
    }
  }
  // Now in CSS, we only have to style the SPAN (how it looks before fade is added) and the class "fade" (how it should look, when the class is added).
  // See CSS-file "textanimation.css" for inspiration.

  // add second animation that starts when the first one has ended.

  function addClass2() {
    let span = animationText.querySelectorAll("span")[letter];
    console.log(span);
    span.classList.add("colorChange");
    console.log(span);
    letter++;

    //   Stop the function when class has been added to all letters.
    if (letter === splitText.length) {
      letter = 0;
      complete2();
      timer3 = setInterval(addClass3, 100); //start the next animation, when this one is completed.
      // Maybe try and change the number 100 and see what happens to the animation.
      return;
    }
  }
  // Now in CSS, we only have to style class "colorChange" (how it should look, when the class is added).
  // See CSS-file "textanimation.css" for inspiration.

  // add a third animation that starts when the second one has ended.
  // In this one we use the reversed array, that we created in the beginning.
  function addClass3() {
    let span = reversed[letter];
    console.log(span);
    span.classList.add("scale");
    console.log(span);
    letter++;

    //   Stop the function when class has been added to all letters.
    if (letter === splitText.length) {
      letter = 0;
      complete3();
      return;
    }
  }
}
// Now in CSS, we only have to style class "scale" (how it should look, when the class is added).
// See CSS-file "textanimation.css" for inspiration.
