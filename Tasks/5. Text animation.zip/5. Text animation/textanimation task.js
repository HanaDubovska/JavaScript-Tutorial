// Create text that needs to be animated and append it to the HTML.
// type "paragraph"
// text: "My first JS animation"


// Now we need to extract each letter from the p-element and put them into an array.

// ...and hide the original textelement.

// Now we can loop through the array and wrap each letter in a <span>.
// That way we can later add a new class to the letters in different ways.

// For later use we will also make an array with the letters in the reverse order.


// Now its time to set the variables and clear-functions that we need for each animation, before we can actually make the animation function.

  // 1st animation...Now create a function that adds a new class to each letter in a certain time interval.
 
    //   Stop the function when class has been added to all letters.
 
 
  // Now in CSS, we only have to style the SPAN (how it looks before fade is added) and the class "fade" (how it should look, when the class is added).
  // See CSS-file "textanimation.css" for inspiration.

  // add second animation that starts when the first one has ended.


    //   Stop the function when class has been added to all letters.
  
  // Now in CSS, we only have to style class "colorChange" (how it should look, when the class is added).
  // See CSS-file "textanimation.css" for inspiration.

  // add a third animation that starts when the second one has ended.
  // In this one we use the reversed array, that we created in the beginning.
 
    //   Stop the function when class has been added to all letters.
 
// Now in CSS, we only have to style class "scale" (how it should look, when the class is added).
// See CSS-file "textanimation.css" for inspiration.
