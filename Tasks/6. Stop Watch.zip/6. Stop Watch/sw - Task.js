// Marco Calderaro
// (Stop Watch)
// Create the value that defines miliseconds, seconds & minutes

// Create values that shows the extra 0 in the text

// Create the value that starts at 0 instead of running when opening page

// Create the value that defines if it has started or stopped

// Create the function of the stopwatch
// When we start the stopwatch the miliseconds will increment up till 100,
// and start over and then increment seconds.     
// Same goes for seconds, but because there is 60 seconds to a minut, we will
// let it go up to 60 and then increment minuts and starts seconds at 0  
// If seconds/minuts are 0-9, add a 0 to the value 
// Display the values for minutes, seconds & miliseconds to the html

// Take the start button id from the html so you can change the element
// Make function to start and stop the stopwatch
// Every 10 miliseconds it will update the time
// When you "click" on "start button", tell the function "gono" to start

// Take the reset button id from the html so you can change the element
// Function to reset the stopwatch
// Clears the ongoing interval and reset the values back to 0
// When you "click" on "Reset" button it tells the function "back" to start



