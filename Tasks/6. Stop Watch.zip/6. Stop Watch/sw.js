// Marco Calderaro
// Creates the variable that defines miliseconds, seconds & minutes
let miliseconds = 0;
let seconds = 0;
let minutes = 0;

// Create variable that shows the extra 0 in the text
let textseconds = 0;
let textminues = 0;

// Creates the variable that defines if it has started or stopped
let situation  = "stopped";

// Creates the function of the stopwatch
function watch() {
    miliseconds++;
    if (miliseconds / 100 === 1) { // When we start the stopwatch the miliseconds will increment up till 100,
        miliseconds = 0;          //  and start over and then increment seconds.  
        seconds++;

    if (seconds / 60 ===1){       // Same goes for seconds, but because there is 60 seconds to a minut, we will
        seconds = 0;              // let it go up to 60 and then increment minuts and starts seconds at 0  
        minutes++;
    }    
        
    }

    // If seconds/minuts are 0-9 it adds a 0 to the value. The toString adds the "0" as a text to the seconds & minutes
    if (seconds < 10){
        textseconds = "0" + seconds.toString();
    }
    else{
        textseconds = seconds;
    }
    if (minutes < 10){
        textminues = "0" + minutes.toString();
    }
    else{
        textminues = minutes;
    } 

    // Displayes the values for minutes, seconds & miliseconds to the html
    document.getElementById("time").innerHTML = textminues + ":" + textseconds + ":" + miliseconds;
}
// Takes the id´s from the html so you can change the element
let ssbtn = document.getElementById("startStopbtn")

// Function to start and stop the stopwatch
function gono(){
    if (situation === "stopped"){
        // Starts the watch 
        ssbtn = window.setInterval(watch, 10); // will call the 'watch' function and update the time every 10 miliseconds
        document.getElementById("startStopbtn").innerHTML = "stop";
        situation = "started";

    }   
    else{
        // Stops the watch
        window.clearInterval(ssbtn);
        document.getElementById("startStopbtn").innerHTML = "start";
        situation = "stopped";
    }

}
// When you "click" on "start button" it tells the function "gono" to start, same goes for stop
ssbtn.addEventListener("click", gono);

// Takes the id´s from the html so you can change the element
let resetbtn = document.getElementById("Resetbtn");

function back() {
    window.clearInterval(); // Clears the ongoing interval and reset the values back to 0
    miliseconds = 0;
    seconds = 0;
    minutes = 0;
    document.getElementById("time").innerHTML = "00:00:00"; // Resets the display
    document.getElementById("startStopbtn").innerHTML = "start"; // Resets the button back to 'start'

}

// When you "click" on "Reset" button it tells the function "back" to start
resetbtn.addEventListener("click", back);


